# Derya Dilara — portfolio prototype

Open **index.html** in a browser. It works offline: fonts and original placeholder illustrations are embedded. Everything is in this new folder; existing site files have not been changed. No site has been published and no domain settings have been changed.

## What this draft contains

A white, scattered image gallery inspired by LAUVENT's spacing and typography, followed by About, four project stories, background/CV and contact. Menu and gallery links move within the same continuous page. Keyboard focus reveals project captions; smaller screens and touch devices show titles without hover. Motion respects the reader's reduced-motion preference.

The artwork is original geometric placeholder artwork, not the user's portfolio work and not copied from LAUVENT. Text is a draft. Name styling “Derya Dilara” and all copy should be reviewed. The full CV, email and social links are intentionally pending; there are no fake downloads or contact links.

## Install into Carrd — use a duplicate draft

1. Duplicate the existing site first, or create a separate blank draft. Do not replace the live deryadilara.com site while reviewing.
2. Use a white page background. Set the page width as wide as Carrd permits, remove page/container padding, and give the Embed the full available width. The layout adapts to its available width; a narrow parent container will constrain it. Avoid rounded containers, shadows and extra surrounding spacers.
3. Add an **Embed** element. Set **Type: Code** and **Style: Inline**. Copy the entire contents of **carrd-embed.html** into Code. This is a fragment: do not paste index.html or add an iframe.
4. Keep this portfolio in one continuous Carrd section. Avoid using Carrd section breaks inside it. The script scrolls to namespaced project IDs without changing Carrd's URL hash.
5. Save as an unpublished draft if that option is available. Carrd's builder does not render custom embeds: review index.html locally now. A later published preview requires a separate preview address and permission to publish; do not change the existing domain as part of this installation.
6. When ready for publication later, set the Carrd site title, description and favicon in Carrd, replace the draft content and verify the published result on a phone and desktop.

Carrd documents Code embeds as requiring Pro Standard or higher: https://carrd.com/docs/building/embedding-custom-code . Account entitlement and the final Carrd rendering still need to be checked in the account. There is no need to buy the reference template.

## Fonts, images and editing

- **Local preview:** index.html embeds Instrument Sans and Instrument Serif, so it has no external font or image requests. It can be shared as a single file.
- **Carrd version:** carrd-embed.html loads Instrument Sans and Instrument Serif from Google Fonts to keep the pasted code compact. This needs an internet connection and the browser contacts Google Fonts. If unavailable, Arial/Georgia remain readable. Font files and their licenses are also included for self-hosting. Self-hosted font URLs must be public HTTPS URLs and allow cross-origin loading.
- **CSS scope:** all portfolio styles are under `#dda-portfolio`. It does not alter Carrd's body, page or other elements. Carrd's outer width/padding must be set in the editor. Embed only once per page.
- **Text:** search the embed for the visible words and edit between the HTML tags. Keep IDs such as `dda-about` and `dda-globe` intact so navigation works. Text inside custom code is not edited with Carrd native text controls.
- **Images:** replace an image's `src="data:image/svg+xml;base64,..."` with a direct public HTTPS image URL and update its `alt` description. Replace both gallery and project-section occurrences. Real photos should be compressed JPG/WebP files; keep filenames/URLs stable. A private Drive sharing page is not a direct image URL. Custom Embed images are **not editable through Carrd native image controls**; image hosting must be arranged separately, or the page must be rebuilt with native Carrd elements.
- **CV/contact:** replace the pending notes with a real CV link, email link and chosen social links only after those are supplied. Remove the draft and placeholder labels after final content review.
- **Maintain both outputs:** source/build.py generates index.html and carrd-embed.html together. Edit its text, styles and project list, then run `python3 source/build.py` from this folder. Font files already in assets/fonts are sufficient; temporary download paths are optional. The build script is a convenience, not needed to view or install the result. source/portfolio.css is an inspection copy; edit styles in build.py to regenerate.

## Content still needed

Your selected images and permission to show them; the three blog names and links; individual project names, dates, your exact role and approved descriptions; designer/gallery credits; education qualification titles and dates; confirmed awards/grants and publication title; a CV PDF; public email/social links. No private case details are included.

## Files

- index.html — complete offline preview
- carrd-embed.html — code to paste into one Carrd Inline Embed
- carrd-preview.html — local wrapper for checking the exact Carrd fragment (Google Fonts online)
- assets/ — original SVG studies, fonts and licenses
- source/build.py — optional source generator
- VALIDATION.md — checks and limits

Reference: https://lauvent.framer.website/ . The draft borrows the idea of a sparse image grid, not its source, template, images or project content.

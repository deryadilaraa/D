from pathlib import Path
import base64, shutil, zipfile
ROOT=Path(__file__).resolve().parents[1]
for name,src in [('InstrumentSans.ttf','/private/tmp/InstrumentSans.ttf'),('InstrumentSerif-Regular.ttf','/private/tmp/InstrumentSerif-Regular.ttf')]:
    if Path(src).exists(): shutil.copy(src, ROOT/'assets/fonts'/name)
def font(name): return base64.b64encode((ROOT/'assets/fonts'/name).read_bytes()).decode()
css='''
@font-face{font-family:DDA Sans;src:url(data:font/ttf;base64,SANS_DATA) format('truetype');font-weight:400 700;font-display:swap}
@font-face{font-family:DDA Serif;src:url(data:font/ttf;base64,SERIF_DATA) format('truetype');font-weight:400;font-display:swap}
#dda-portfolio{--ink:#111;--muted:#626262;background:#fff;color:var(--ink);font:16px/1.45 'DDA Sans',Arial,sans-serif;text-align:left;width:100%;max-width:none;isolation:isolate;overflow-wrap:break-word}
#dda-portfolio *,#dda-portfolio *::before,#dda-portfolio *::after{box-sizing:border-box}
#dda-portfolio :where(h1,h2,h3,p,figure,ul){margin:0;padding:0}
#dda-portfolio a{color:inherit;text-decoration:none;border:0;box-shadow:none}
#dda-portfolio a:focus-visible,#dda-portfolio summary:focus-visible{outline:2px solid #1547df;outline-offset:5px}
#dda-portfolio a:hover{text-decoration:underline;text-underline-offset:4px}
#dda-portfolio .dda-skip{position:absolute;left:20px;top:-80px;z-index:10;background:white;padding:12px}
#dda-portfolio .dda-skip:focus{top:8px}
#dda-portfolio .dda-header{display:flex;justify-content:space-between;align-items:start;position:relative;z-index:5;padding:22px 24px 16px;font-weight:700;font-size:17px;line-height:1.2}
#dda-portfolio .dda-brand{letter-spacing:-.7px}
#dda-portfolio .dda-menu{min-width:84px;text-align:right}
#dda-portfolio summary{list-style:none;cursor:pointer;padding:0 0 8px}
#dda-portfolio summary::-webkit-details-marker{display:none}
#dda-portfolio summary::after{content:' +'}
#dda-portfolio details[open] summary::after{content:' −'}
#dda-portfolio .dda-nav{position:absolute;right:24px;top:52px;width:220px;padding:24px;background:#fff;box-shadow:0 8px 30px #00000015;text-align:left;display:grid;gap:15px}
#dda-portfolio .dda-opening{padding:0 24px;}
#dda-portfolio .dda-grid{display:grid;grid-template-columns:repeat(9,minmax(0,1fr));gap:20px;grid-template-rows:repeat(4,clamp(105px,10.8vw,160px));max-width:1800px;margin:auto}
#dda-portfolio .dda-tile{position:relative;display:block;min-width:0;height:100%;}
#dda-portfolio .dda-tile img{width:100%;height:100%;object-fit:cover;display:block;transition:filter .2s,transform .3s}
#dda-portfolio .dda-caption{position:absolute;inset:auto 0 0;background:#ffffffed;color:#111;padding:10px 8px;opacity:0;transition:opacity .2s;line-height:1.15;font-size:12px;}
#dda-portfolio .dda-caption strong{display:block;font-weight:700;margin-bottom:5px}
#dda-portfolio .dda-tile:hover .dda-caption,#dda-portfolio .dda-tile:focus-visible .dda-caption{opacity:1}
#dda-portfolio .dda-tile:hover img{filter:saturate(1.08)}
#dda-portfolio .dda-t1{grid-area:1/1}#dda-portfolio .dda-t2{grid-area:1/4}#dda-portfolio .dda-t3{grid-area:1/5}#dda-portfolio .dda-t4{grid-area:1/8}
#dda-portfolio .dda-t5{grid-area:2/1}#dda-portfolio .dda-t6{grid-area:2/2}#dda-portfolio .dda-t7{grid-area:2/8}#dda-portfolio .dda-t8{grid-area:2/9}
#dda-portfolio .dda-t9{grid-area:3/2}#dda-portfolio .dda-t10{grid-area:4/1}#dda-portfolio .dda-t11{grid-area:4/6}#dda-portfolio .dda-t12{grid-area:4/9}
#dda-portfolio .dda-gallery-foot{display:flex;justify-content:space-between;gap:24px;margin:22px 0 0;font-size:12px;line-height:1.4}
#dda-portfolio .dda-gallery-foot a{font-weight:700;white-space:nowrap}
#dda-portfolio .dda-note{color:var(--muted);font-size:12px;line-height:1.5}
#dda-portfolio .dda-about{max-width:1200px;margin:140px auto 130px;padding:0 40px;display:grid;grid-template-columns:1fr 2fr;gap:70px;scroll-margin-top:35px}
#dda-portfolio .dda-label{text-transform:uppercase;letter-spacing:.09em;font-size:11px;font-weight:700}
#dda-portfolio h1{font:400 clamp(42px,5.2vw,76px)/1.01 'DDA Serif',Georgia,serif;letter-spacing:-.035em;max-width:780px;margin:0 0 32px}
#dda-portfolio .dda-intro{font-size:19px;line-height:1.55;max-width:650px}
#dda-portfolio .dda-about .dda-note{margin-top:22px}
#dda-portfolio .dda-work{padding:0 40px;max-width:1440px;margin:auto}
#dda-portfolio .dda-section-head{display:flex;align-items:baseline;justify-content:space-between;padding-bottom:20px;border-bottom:1px solid #cfcfcf}
#dda-portfolio h2{font:400 clamp(36px,4vw,56px)/1.1 'DDA Serif',Georgia,serif;letter-spacing:-.025em}
#dda-portfolio .dda-project{display:grid;grid-template-columns:1fr 1.18fr;gap:9%;padding:80px 0;border-bottom:1px solid #dedede;scroll-margin-top:20px;align-items:center}
#dda-portfolio .dda-project:nth-of-type(odd) .dda-project-art{order:2}
#dda-portfolio .dda-project-art img{width:100%;aspect-ratio:1.14;display:block;object-fit:cover}
#dda-portfolio .dda-project-art figcaption{font-size:11px;color:var(--muted);margin-top:10px}
#dda-portfolio .dda-project-copy{max-width:440px}
#dda-portfolio h3{font:400 clamp(33px,3.7vw,52px)/1.03 'DDA Serif',Georgia,serif;letter-spacing:-.025em;margin:18px 0 22px}
#dda-portfolio .dda-project-copy p:not(.dda-label){margin:0 0 22px;font-size:17px;line-height:1.6}
#dda-portfolio .dda-project-copy .dda-note{font-size:12px!important}
#dda-portfolio .dda-cv{display:grid;grid-template-columns:1fr 2fr;gap:70px;padding:90px 40px;max-width:1200px;margin:auto;scroll-margin-top:20px}
#dda-portfolio .dda-cv-list{list-style:none}
#dda-portfolio .dda-cv-list li{border-bottom:1px solid #ddd;padding:18px 0;display:grid;gap:6px}
#dda-portfolio .dda-cv-list li:first-child{padding-top:0}
#dda-portfolio .dda-cv-list strong{font-size:16px;font-weight:500}
#dda-portfolio .dda-cv-list span{font-size:14px;color:var(--muted)}
#dda-portfolio .dda-contact{margin:0 24px;padding:75px 16px 30px;border-top:1px solid #111;scroll-margin-top:20px}
#dda-portfolio .dda-contact h2{font-size:clamp(54px,8.8vw,128px);max-width:1000px;line-height:.98;margin:20px 0 30px}
#dda-portfolio .dda-contact p{max-width:480px}
#dda-portfolio .dda-contact .dda-note{margin-top:20px}
#dda-portfolio .dda-footer{display:flex;justify-content:space-between;gap:24px;font-size:12px;margin-top:90px}
@media(hover:none){#dda-portfolio .dda-caption{opacity:1}}
@media(min-width:1600px){#dda-portfolio .dda-opening{padding:0 40px}}
@media(max-width:800px){#dda-portfolio .dda-header{padding:20px 18px}#dda-portfolio .dda-opening{padding:0 18px}#dda-portfolio .dda-grid{gap:12px;grid-template-rows:repeat(4,11vw)}#dda-portfolio .dda-caption{position:static;opacity:1;font-size:10px;padding:6px 0;background:white}#dda-portfolio .dda-caption span{display:none}#dda-portfolio .dda-grid{row-gap:42px}#dda-portfolio .dda-about{padding:0 24px;gap:30px;margin:115px auto 85px;grid-template-columns:1fr}#dda-portfolio .dda-intro{font-size:18px}#dda-portfolio .dda-work{padding:0 24px}#dda-portfolio .dda-project{gap:6%;padding:50px 0}#dda-portfolio .dda-cv{padding:65px 24px;grid-template-columns:1fr;gap:30px}#dda-portfolio .dda-contact{margin:0 18px;padding-left:6px;padding-right:6px}}
@media(max-width:540px){#dda-portfolio .dda-grid{grid-template-columns:repeat(4,minmax(0,1fr));grid-template-rows:repeat(6,29vw);gap:44px 12px}#dda-portfolio .dda-t1{grid-area:1/1/span 1/span 2}#dda-portfolio .dda-t2{grid-area:1/4}#dda-portfolio .dda-t3{grid-area:2/2}#dda-portfolio .dda-t4{grid-area:2/3/span 1/span 2}#dda-portfolio .dda-t5{grid-area:3/1}#dda-portfolio .dda-t6{grid-area:3/3}#dda-portfolio .dda-t7{grid-area:4/1/span 1/span 2}#dda-portfolio .dda-t8{grid-area:4/4}#dda-portfolio .dda-t9{grid-area:5/2}#dda-portfolio .dda-t10{grid-area:5/3/span 1/span 2}#dda-portfolio .dda-t11{grid-area:6/1}#dda-portfolio .dda-t12{grid-area:6/4}#dda-portfolio .dda-caption{font-size:10px}#dda-portfolio .dda-gallery-foot{margin-top:44px}#dda-portfolio .dda-gallery-foot .dda-note{max-width:210px;font-size:10px}#dda-portfolio .dda-about{margin-top:85px}#dda-portfolio .dda-project{grid-template-columns:1fr;gap:30px}#dda-portfolio .dda-project:nth-of-type(odd) .dda-project-art{order:0}#dda-portfolio .dda-section-head .dda-note{max-width:105px;text-align:right}#dda-portfolio .dda-footer{margin-top:65px;flex-wrap:wrap}}
@media(prefers-reduced-motion:reduce){#dda-portfolio *{transition:none!important;scroll-behavior:auto!important}}
'''
# Original geometric studies, created for this prototype. No reference template assets.
palettes=[('#ff693b','#ffd73e','#f036a4'),('#193ab8','#e9adff','#fd7738'),('#ec2861','#ffae38','#821b49'),('#d8e246','#fc542e','#497765'),('#1c244d','#efeff9','#e8bc77'),('#e8ade4','#f34225','#752eed'),('#d87930','#ffd393','#95293a'),('#b6caec','#ed3728','#112f8d'),('#eee9dc','#153d36','#ff6634'),('#86cdd0','#fff293','#ec68a4'),('#efaeae','#8358cf','#fdeb54'),('#b8a2f2','#ffff5a','#ff5f23')]
images=[]
for i,(bg,a,b) in enumerate(palettes):
    n=i+1
    if i%4==0: shapes=f'<circle cx="210" cy="220" r="142" fill="{a}"/><path d="M40 365 Q200 60 375 345L375 470H40Z" fill="{b}"/><circle cx="250" cy="180" r="65" fill="{bg}"/>'
    elif i%4==1: shapes=''.join(f'<ellipse cx="200" cy="{150+j*48}" rx="{145-j*9}" ry="38" fill="{a if j%2==0 else b}" transform="rotate(-18 200 240)"/>' for j in range(5))
    elif i%4==2: shapes=f'<path d="M70 80H310V160H150V235H305V315H150V420H70Z" fill="{a}"/><circle cx="278" cy="360" r="79" fill="{b}"/>'
    else: shapes=f'<path d="M200 55L238 160L350 110L302 220L375 280L262 302L270 430L188 350L90 435L113 310L20 260L126 215L80 110L176 156Z" fill="{a}"/><circle cx="198" cy="246" r="51" fill="{b}"/>'
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="400" height="500" viewBox="0 0 400 500"><rect width="400" height="500" fill="{bg}"/>{shapes}<text x="22" y="477" font-family="Arial,sans-serif" font-size="11" letter-spacing="2" fill="#111">COLOUR STUDY / {n:02d}</text></svg>'
    (ROOT/f'assets/study-{n:02d}.svg').write_text(svg)
    images.append('data:image/svg+xml;base64,'+base64.b64encode(svg.encode()).decode())
titles=['DDA Globe','Digital stories','Designer dialogues','In public','Visual journals','Colour & form','Designer dialogues','Digital stories','Visual journals','In public','DDA Globe','Colour & form']
targets=['dda-globe','dda-stories','dda-designers','dda-public','dda-globe','dda-designers','dda-designers','dda-stories','dda-globe','dda-public','dda-globe','dda-public']
tiles=''.join(f'<a class="dda-tile dda-t{i+1}" href="#{targets[i]}" aria-label="{titles[i]} — view project section"><img src="{images[i]}" alt="Original abstract colour study {i+1}; project image placeholder" width="400" height="500"><span class="dda-caption"><strong>{titles[i]}</strong><span>View more ↗</span></span></a>' for i in range(12))
projects=[('dda-globe','01 / Independent practice','DDA Globe','Document Design Act is my independent creative practice, grown from three ongoing Instagram blogs. A place for visual curiosity, curation and stories that connect words with images.','Add the three blog names, links and a selected editorial series.',0),('dda-stories','02 / Digital storytelling','Stories that make<br>space for people','My digital storytelling work includes the University of Melbourne and galleries. I look for the human detail: the observation, voice or image that gives a story its meaning.','Add a specific project title, your role, dates and approved work samples.',1),('dda-designers','03 / Creative collaboration','A dialogue with<br>design','Collaborations with international fashion and jewellery designers bring together my interests in identity, craft and visual storytelling.','Add designer names, collaboration details and images cleared for use.',5),('dda-public','04 / Art & place','Beyond the screen','A place for public art and installation projects: stories encountered in shared spaces, through colour, form and human connection.','Project selection, locations, dates and credits to be confirmed.',9)]
projecthtml=''.join(f'<article class="dda-project" id="{id}" tabindex="-1"><figure class="dda-project-art"><img src="{images[im]}" alt="Abstract colour study; placeholder for {title.replace("<br>"," ")}" width="400" height="500" loading="lazy"><figcaption>Original placeholder artwork / replace with project image</figcaption></figure><div class="dda-project-copy"><p class="dda-label">{label}</p><h3>{title}</h3><p>{desc}</p><p class="dda-note">Draft project section · {note}</p></div></article>' for id,label,title,desc,note,im in projects)
html=f'''<div id="dda-portfolio">
<a class="dda-skip" href="#dda-about">Skip gallery to About</a>
<header class="dda-header" id="dda-top"><a class="dda-brand" href="#dda-top" aria-label="Derya Dilara, back to top">DERYA DILARA</a><details class="dda-menu"><summary>Menu</summary><nav class="dda-nav" aria-label="Portfolio"><a href="#dda-work">Selected work</a><a href="#dda-about">About</a><a href="#dda-cv">CV</a><a href="#dda-contact">Contact</a></nav></details></header>
<main><section class="dda-opening" aria-label="Selected project gallery"><div class="dda-grid">{tiles}</div><div class="dda-gallery-foot"><p class="dda-note">Portfolio draft · All gallery images are placeholders.</p><a href="#dda-about">A little about me ↓</a></div></section>
<section class="dda-about" id="dda-about" tabindex="-1"><p class="dda-label">About / A way of seeing</p><div><h1>Observing people.<br>Connecting stories.<br>Making room for joy.</h1><p class="dda-intro">I’m Derya Dilara, a digital storyteller, curator and creative communicator. I pay attention to what people say—and what they leave unsaid. Those human details shape my words and images. I’m drawn to beauty that stays with us, and to colour that makes us feel something.</p><p class="dda-note">My practice spans independent creative work and government communications. I’m interested in bringing that perspective to agencies, brands and cultural projects.</p></div></section>
<section class="dda-work" id="dda-work" tabindex="-1" aria-labelledby="dda-work-title"><div class="dda-section-head"><h2 id="dda-work-title">Selected work</h2><p class="dda-note">Four starting points.<br>More stories to come.</p></div>{projecthtml}</section>
<section class="dda-cv" id="dda-cv" tabindex="-1" aria-labelledby="dda-cv-title"><h2 id="dda-cv-title">A little background</h2><div><ul class="dda-cv-list"><li><strong>Independent creative practice</strong><span>DDA Globe / Document Design Act</span></li><li><strong>Communications & storytelling</strong><span>Experience across government, creative and cultural contexts</span></li><li><strong>Education</strong><span>Deakin University & VCA — qualification titles and dates to confirm</span></li><li><strong>Selected recognition & publications</strong><span>Awards, grants and publication details to be added after confirmation</span></li></ul><p class="dda-note" style="margin-top:20px">CV draft · Full CV will be linked here when supplied.</p></div></section>
<section class="dda-contact" id="dda-contact" tabindex="-1" aria-labelledby="dda-contact-title"><p class="dda-label">Contact</p><h2 id="dda-contact-title">Let’s make something<br>that stays.</h2><p>For creative collaborations, agency opportunities and stories worth telling.</p><p class="dda-note">Contact details to be added · Email and social links will appear here.</p><footer class="dda-footer"><span>© 2026 Derya Dilara</span><a href="#dda-top">Back to top ↑</a><span>Words, images & human things.</span></footer></section></main></div>'''
js='''(()=>{const root=document.getElementById('dda-portfolio');if(!root)return;root.addEventListener('click',e=>{const link=e.target.closest('a[href^="#dda-"]');if(!link)return;const target=root.querySelector(link.getAttribute('href'));if(!target)return;e.preventDefault();const menu=root.querySelector('details');if(menu)menu.open=false;target.scrollIntoView({behavior:window.matchMedia('(prefers-reduced-motion: reduce)').matches?'auto':'smooth',block:'start'});if(!target.hasAttribute('tabindex'))target.setAttribute('tabindex','-1');target.focus({preventScroll:true});});root.addEventListener('keydown',e=>{if(e.key==='Escape'){const menu=root.querySelector('details');if(menu&&menu.open){menu.open=false;menu.querySelector('summary').focus();}}});})();'''
css=css.replace('SANS_DATA',font('InstrumentSans.ttf')).replace('SERIF_DATA',font('InstrumentSerif-Regular.ttf'))
embed=f'<style>\n{css}\n</style>\n{html}\n<script>\n{js}\n</script>'
(ROOT/'carrd-embed.html').write_text(embed)
(ROOT/'index.html').write_text(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Derya Dilara — Creative portfolio draft</title><meta name="description" content="Digital storytelling, curation and creative communication by Derya Dilara. Review prototype."><meta name="robots" content="noindex,nofollow"><style>body{{margin:0;background:white}}</style></head><body>{embed}</body></html>')
# Readable authoring copy uses local fonts; generated outputs above are completely standalone.
(ROOT/'source/portfolio.css').write_text(css.replace(font('InstrumentSans.ttf'),'FONT_DATA_EMBEDDED_DURING_BUILD').replace(font('InstrumentSerif-Regular.ttf'),'FONT_DATA_EMBEDDED_DURING_BUILD'))
print(f'Built {ROOT}/index.html and carrd-embed.html ({len(embed):,} characters)')
# Carrd-friendly compact version: Google Fonts are the only external dependencies.
import re
compact=re.sub(r'@font-face\{[^}]+\}', '', css)
compact="@import url('https://fonts.googleapis.com/css2?family=Instrument+Sans:wght@400;500;600;700&family=Instrument+Serif&display=swap');\n"+compact.replace("'DDA Sans'","'Instrument Sans'").replace("'DDA Serif'","'Instrument Serif'")
compact_embed=f'<style>\n{compact}\n</style>\n{html}\n<script>\n{js}\n</script>'
(ROOT/'carrd-embed.html').write_text(compact_embed)
(ROOT/'carrd-preview.html').write_text(f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Derya Dilara — Carrd embed test</title><style>body{{margin:0}}</style></head><body>{compact_embed}</body></html>')
print(f'Carrd embed: {len(compact_embed):,} characters; offline preview keeps embedded fonts.')
